Add your application sources such as java class files to this folder. 
Files added to this folder will be copied to WEB-INF/classes/ for deployment.